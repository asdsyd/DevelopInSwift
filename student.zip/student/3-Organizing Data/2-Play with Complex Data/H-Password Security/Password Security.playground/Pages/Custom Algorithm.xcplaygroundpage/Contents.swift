/*:
## Custom Algorithm
 Think about more rules you could add to make your users' passwords even more secure. Implement your algorithm below.

 You can copy the code from the previous page as a starting point.
 */
 
/*:
[Previous](@previous)  |  page 4 of 5  |  [Next: Brute-Force Guessing](@next)
 */